# Optional Assignment – Advanced Topics in Neural Networks

## Summary of Work

- Designed a small **neural network** (`TinyTransformNet`) to learn this transformation. The network takes a 3×32×32 RGB image and outputs a 1×28×28 grayscale image.
- Used **L1 loss** to train the model to approximate the target transformation.
- Applied **early stopping** based on validation loss to avoid overfitting and reduce training time.
- Measured performance using the provided `test_inference_time` function:
  - Sequential CPU transformations for all images.
  - Batched neural network inference.
- Achieved faster inference with the model compared to sequential CPU transformations (~0.2s vs ~1.3s).
- **Debugging note:** On Windows, using `num_workers > 0` in `DataLoader` can sometimes cause **slowdowns or hangs** due to how multiprocessing works with Windows. For this reason, `num_workers` was set to `0` to ensure consistent and fast CPU training.

## Expected Points

| Task | Points |
|------|--------|
| Model implementation | 3 |
| Loss function | 2 |
| Early stopping | 2 |
| Visual comparison of outputs | 1 |
| Runtime benchmarking | 2 |
| **Total** | **10 / 10** |
